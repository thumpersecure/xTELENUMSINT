Installation
	1.	Open Chrome → chrome://extensions/
	2.	Enable “Developer mode”
	3.	Click “Load unpacked”
	4.	Select the telespot-numsint folder
Future Options (as mentioned)
The extension is structured to easily add:
	∙	site: operator filtering
	∙	Other Google search operators
	∙	Result summarization